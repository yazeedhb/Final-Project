﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace UserReferralSystem
{
    public partial class Form2 : Form
    {
        private Form1 loginForm;
        private string currentUsername;
        private string currentPassword;



        public Form2(string username, int points, string referralCode, string password, Form1 callingForm)
        {
            InitializeComponent();
            // Set Form background to Robinhood green
            this.BackColor = Color.FromArgb(0, 200, 5);

            // Style all buttons
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Button btn)
                {
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.BackColor = Color.White;
                    btn.ForeColor = Color.FromArgb(0, 200, 5); // Robinhood green text
                    btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
                }
            }

            // Style all labels
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Label lbl)
                {
                    lbl.ForeColor = Color.White;
                    lbl.BackColor = Color.Transparent;
                    lbl.Font = new Font("Segoe UI", 10, FontStyle.Regular);
                }
            }

            lblUsername.Text = $"Username: {username}";
            lblPoints.Text = $"Points: {points}";
            lblReferralCode.Text = $"Referral Code: {referralCode}";

            currentUsername = username;
            currentPassword = password;
            loginForm = callingForm;
        }



        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Close();
        }


        private void btnEditProfile_Click(object sender, EventArgs e)
        {


            Form3 form3 = new Form3(currentUsername, currentPassword, this);
            form3.Show();
            this.Hide();

        }

        private void btnLeaderboard_Click(object sender, EventArgs e)
        {
            Form4 leaderboardForm = new Form4(currentUsername, this);
            leaderboardForm.Show();
            this.Hide(); // optional
        }
        public void UpdateProfile(string newUsername, string referralCode, int points)
        {
            currentUsername = newUsername;
            lblUsername.Text = $"Username: {newUsername}";
            lblReferralCode.Text = $"Referral Code: {referralCode}";
            lblPoints.Text = $"Points: {points}";
        }
        public void RefreshUserInfo()
        {
            // Re-fetch user data from the database and update the labels
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={Form1.dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT ReferralCode, Points FROM Users WHERE Username = @Username";
                using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", currentUsername);
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            lblPoints.Text = "Points: " + reader["Points"].ToString();
                            lblReferralCode.Text = "Referral Code: " + reader["ReferralCode"].ToString();
                        }
                    }
                }
            }
        }





    }

}
