﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserReferralSystem
{

    public partial class Form3 : Form
    {
        private string currentUsername;
        private string currentPassword;
        private Form2 callingForm;

        public Form3(string username, string password, Form2 form)
        {
            InitializeComponent();
            currentUsername = username;
            currentPassword = password;
            callingForm = form;
            // 🌿 Robinhood theme styling for Form3
            this.BackColor = Color.FromArgb(0, 200, 5); // Form background: green

            // Style all buttons
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Button btn)
                {
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.BackColor = Color.White;
                    btn.ForeColor = Color.FromArgb(0, 200, 5); // Green text
                    btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
                    btn.Width = 120;
                    btn.Height = 40;
                }
            }

            // Style all labels
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Label lbl)
                {
                    lbl.ForeColor = Color.White;
                    lbl.BackColor = Color.Transparent;
                    lbl.Font = new Font("Segoe UI", 10, FontStyle.Regular);
                }
            }

            // Style all textboxes
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is TextBox txt)
                {
                    txt.BackColor = Color.White;
                    txt.ForeColor = Color.Black;
                    txt.Font = new Font("Segoe UI", 10, FontStyle.Regular);
                }
            }

            currentUsername = username;
            currentPassword = password;
        }



        private void Form3_Load(object sender, EventArgs e)
        {
            // You can leave this empty or add logic
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string newUsername = txtUsername.Text.Trim();
            string newPassword = txtPassword.Text.Trim();

            using (var conn = new SQLiteConnection($"Data Source={Form1.dbPath};Version=3;"))
            {
                conn.Open();

                // 1. Update username and password
                string updateQuery = "UPDATE Users SET Username = @NewUsername, Password = @NewPassword " +
                                     "WHERE Username = @OldUsername AND Password = @OldPassword";
                using (var cmd = new SQLiteCommand(updateQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@NewUsername", newUsername);
                    cmd.Parameters.AddWithValue("@NewPassword", newPassword);
                    cmd.Parameters.AddWithValue("@OldUsername", currentUsername);
                    cmd.Parameters.AddWithValue("@OldPassword", currentPassword);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("Profile updated successfully.");

                        // 2. Refresh updated user data
                        string fetchQuery = "SELECT ReferralCode, Points FROM Users WHERE Username = @NewUsername";
                        using (var fetchCmd = new SQLiteCommand(fetchQuery, conn))
                        {
                            fetchCmd.Parameters.AddWithValue("@NewUsername", newUsername);
                            using (var reader = fetchCmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    string updatedReferralCode = reader["ReferralCode"].ToString();
                                    int updatedPoints = Convert.ToInt32(reader["Points"]);

                                    // Update Form2 labels
                                    callingForm.UpdateProfile(newUsername, updatedReferralCode, updatedPoints);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Update failed. Please check your data.");
                    }
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close(); // or redirect to another form if needed
        }
        private void btnBackToMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            callingForm.Show(); // ✅ return to Form2
        }

    }

}

