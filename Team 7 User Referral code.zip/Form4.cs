﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SQLite;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace UserReferralSystem
{
    public partial class Form4 : Form

    {
        private string currentUsername;
        private Form2 callingForm;


        public Form4(string username, Form2 callingForm)
        {
            InitializeComponent();
            this.callingForm = callingForm;
            currentUsername = username;
            // Back Button Style
            btnBack.BackColor = Color.White;
            btnBack.ForeColor = Color.Black;
            btnBack.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnBack.Size = new Size(80, 30);


            // Neon green background and dark theme elements
            this.BackColor = Color.FromArgb(208, 255, 0); // Neon green

            // Style DataGridView
            dataGridViewLeaderboard.BackgroundColor = Color.Black;
            dataGridViewLeaderboard.GridColor = Color.Black;
            dataGridViewLeaderboard.DefaultCellStyle.BackColor = Color.FromArgb(208, 255, 0); // Neon green
            dataGridViewLeaderboard.DefaultCellStyle.ForeColor = Color.Black;
            dataGridViewLeaderboard.DefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dataGridViewLeaderboard.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(208, 255, 0);
            dataGridViewLeaderboard.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridViewLeaderboard.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dataGridViewLeaderboard.EnableHeadersVisualStyles = false;
            progressBar1.ForeColor = Color.Black;
            progressBar1.Style = ProgressBarStyle.Continuous;

            foreach (DataGridViewRow row in dataGridViewLeaderboard.Rows)
            {
                if (row.Cells["Username"].Value != null &&
                    row.Cells["Username"].Value.ToString() == currentUsername)
                {
                    row.DefaultCellStyle.BackColor = Color.Yellow;
                    row.DefaultCellStyle.ForeColor = Color.Black;
                }
            }


            currentUsername = username;
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            using (var conn = new SQLiteConnection($"Data Source={Form1.dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT Username, Points FROM Users ORDER BY Points DESC";

                using (var cmd = new SQLiteCommand(query, conn))
                using (var adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    // Add a new Rank column
                    table.Columns.Add("Rank", typeof(string));

                    for (int i = 0; i < table.Rows.Count; i++)
                    {
                        if (i == 0)
                            table.Rows[i]["Rank"] = "🥇 1st";
                        else if (i == 1)
                            table.Rows[i]["Rank"] = "🥈 2nd";
                        else if (i == 2)
                            table.Rows[i]["Rank"] = "🥉 3rd";
                        else
                            table.Rows[i]["Rank"] = (i + 1).ToString();
                    }


                    // Move Rank column to first position
                    table.Columns["Rank"].SetOrdinal(0);

                    dataGridViewLeaderboard.DataSource = table;
                    // 🥇 Show current user's rank in lblUserRank
                    int userRank = -1;

                    for (int i = 0; i < table.Rows.Count; i++)
                    {
                        if (table.Rows[i]["Username"].ToString() == currentUsername)
                        {
                            userRank = i + 1;
                            break;
                        }
                    }

                    if (userRank > 0)
                    {
                        lblUserRank.Text = $"You are currently ranked #{userRank}!";

                        // Estimate progress to next rank (based on how far you are from the top)
                        int totalUsers = table.Rows.Count;
                        double progress = (1.0 - ((double)(userRank - 1) / totalUsers)) * 100;

                        // Clamp between 0 and 100
                        progressBar1.Value = Math.Min(100, Math.Max(0, (int)progress));
                    }
                    else
                    {
                        lblUserRank.Text = $"You're not ranked yet.";
                        progressBar1.Value = 0;
                    }


                    // Color top 3 rows
                    for (int i = 0; i < dataGridViewLeaderboard.Rows.Count; i++)
                    {
                        if (i == 0)
                            dataGridViewLeaderboard.Rows[i].DefaultCellStyle.BackColor = Color.Gold;
                        else if (i == 1)
                            dataGridViewLeaderboard.Rows[i].DefaultCellStyle.BackColor = Color.Silver;
                        else if (i == 2)
                            dataGridViewLeaderboard.Rows[i].DefaultCellStyle.BackColor = Color.Peru; // Bronze-like
                    }


                    foreach (DataGridViewRow row in dataGridViewLeaderboard.Rows)
                    {
                        if (row.Cells["Username"].Value != null &&
                            row.Cells["Username"].Value.ToString() == currentUsername)
                        {
                            row.DefaultCellStyle.BackColor = Color.Yellow;
                        }
                    }

                }
            }
        }

        private void lblUserRank_Click(object sender, EventArgs e)
        {

        }
            private void btnBack_Click(object sender, EventArgs e)
        {
            callingForm.RefreshUserInfo(); // This refreshes Form2’s data
            callingForm.Show();
            this.Close();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }

}

