﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserReferralSystem
{
    public partial class Form1 : Form
    {
        private string dbPath = @"DataBase\users.db";
        private SQLiteConnection conn;

        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string referralCodeUsed = txtReferralCode.Text.Trim();
            string generatedReferralCode = Guid.NewGuid().ToString().Substring(0, 8);

            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter Username and Password.");
                return;
            }

            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();

                // Check if username exists
                string checkUser = "SELECT COUNT(*) FROM Users WHERE Username = @Username";
                using (var cmdCheck = new SQLiteCommand(checkUser, conn))
                    NewMethod(username, cmdCheck);

                // Insert new user
                int points = 100;
                string insertQuery = "INSERT INTO Users (Username, Password, Points, ReferralCode, ReferredBy) VALUES (@Username, @Password, @Points, @ReferralCode, @ReferredBy)";
                using (var cmdInsert = new SQLiteCommand(insertQuery, conn))
                {
                    cmdInsert.Parameters.AddWithValue("@Username", username);
                    cmdInsert.Parameters.AddWithValue("@Password", password);
                    cmdInsert.Parameters.AddWithValue("@Points", points);
                    cmdInsert.Parameters.AddWithValue("@ReferralCode", generatedReferralCode);
                    cmdInsert.Parameters.AddWithValue("@ReferredBy", referralCodeUsed);
                    cmdInsert.ExecuteNonQuery();
                }

                MessageBox.Show("Registration successful!");
            }
        }

        private static void NewMethod(string username, SQLiteCommand cmdCheck)
        {
            cmdCheck.Parameters.AddWithValue("@Username", username);
            long count = (long)cmdCheck.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("Username already exists. Please choose another one.");
                return;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
        
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter Username and Password.");
                return;
            }

            using (var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;"))
            {
                conn.Open();
                string query = "SELECT * FROM Users WHERE Username = @Username AND Password = @Password";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Login successful
                            string referralCode = reader["ReferralCode"].ToString();
                            int points = Convert.ToInt32(reader["Points"]);

                            // Open Form2
                            Form2 profileForm = new Form2(username, points, referralCode);
                            profileForm.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password.");
                        }
                    }
                }
            }
        }

    }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    }

